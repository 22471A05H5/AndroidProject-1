package com.example.myproject

    data class User(
val username: String? = null,
// Add other fields if needed
)
